import { useState } from 'react'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';

import Home from "./pages/Home.jsx";
import About from "./pages/About.jsx";

function App() {

  return (
    <BrowserRouter>
      {/* Navigation */}
      <nav>
              <ul>
                  <li><Link to="./pages/Home.jsx">Home</Link></li>
                  <li><Link to= "./About.jsx">About</Link>
                      <ul class = "dropdown">
                          <li><a href = "#">Skills</a></li>
                          <li><a href = "#">Contact</a></li>
                      </ul>
                  </li>
                  <li>
                      <a href = "./Projects.jsx">Projects</a>
                      <ul class="dropdown">
                          <li><a href ="#">Past Projects</a></li>
                          <li><a href ="#">Current Projects</a></li>

                      </ul>
                  </li>
                  <li><a href = "">Contact</a></li>
              </ul>
          </nav>
      <Routes>
          <Route path="./pages/Home.jsx" element={<Home />} />
          <Route path="./About.jsx" element={<About />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App
