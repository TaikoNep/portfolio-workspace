import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
export default function About() {

    return(
        <div className="about">
            <title>My About</title>

            <nav>
                <ul>
                    <li><a href = "./Home.jsx">Home</a></li>
                    <li><a href = "./About.jsx">About</a>
                        <ul class = "dropdown">
                            <li><a href = "#">Skills</a></li>
                            <li><a href = "#">Contact</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href = "./Projects.jsx">Projects</a>
                        <ul class="dropdown">
                            <li><a href ="#">Past Projects</a></li>
                            <li><a href ="#">Current Projects</a></li>

                        </ul>
                    </li>
                    <li><a href = "">Contact</a></li>
                </ul>
            </nav>
        </div>
    );


}